let btn = document.getElementById('add-btn');
btn.addEventListener('click' , addFood)
    function addFood(e){
        let currentbtn = e.currentTarget;
        console.log(currentbtn);
        let currentInp = currentbtn.previousElementSibling;
        console.log(currentInp.value);
        let currentFoodName = currentInp.value;
        let newLi = document.createElement('li');
        newLi.className = `list-group-item d-flex justify-content-between`;
        newLi.innerHTML = `
        <h3 class="flex-grow-1">${currentFoodName}</h3>
                <button class=" btn btn-dark mx-2">Read</button>
                <button class=" btn btn-danger ">Delete</button>
        `

        let peranList = document.getElementById('parentList');
        peranList.appendChild(newLi);
        
    };

    // PROMISES
let promiseThree = new Promise(function(resolve , reject){
    setTimeout(function(){
        resolve({username : "john" , age:15 , car:"Aston Martin", colour:"yellow"})
    },1000)
})

promiseThree.then(function(user){
        console.log(user);
    return user.username;
}).then(function(user){
    console.log(user);
})
promiseThree.then(function(user){
return user.car;
}).then(function(user){
console.log(user);
})

// Fatch Data
async function getAllUserData(){
    try{
        let response = await fetch('https://jsonplaceholder.typicode.com/users');
        let jsonData = await response.json()
        console.log((JSON.stringify(jsonData)));
    }

    catch(error){
        console.log("ERROR");
    }
}

getAllUserData();

let Alldata = getAllUserData.value;
console.log(Alldata);